package com.nucleus.webservice;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.nucleus.domain.Customer;


public class JSONData {
	 private Logger logger = Logger.getLogger(JSONData.class.getName());
	public static String getText(String url) throws Exception {
        URL website = new URL(url);
        URLConnection connection = website.openConnection();
        BufferedReader in = new BufferedReader( new InputStreamReader(connection.getInputStream()));

        StringBuilder response = new StringBuilder();
        String inputLine;
    while ((inputLine = in.readLine()) != null) 
        { 
        	response.append(inputLine);
        }
 in.close();
    return response.toString();
       }
	
	
   public List<Customer> getCustomers(String fy, String employeeId, String tokenId) {
	   logger.info("entered in getCustomers method of "+logger.getName());
	   String[] date=fy.split("-");
  	   String sDate="01-04-"+date[0];
	   String eDate="31-03-"+date[1];
	   logger.info("start date for this fy is: "+sDate + ":	End date : "+eDate);
	   logger.info("employee id: "+employeeId+"  token Id: "+tokenId);
       JSONArray jsonArray=null;      
	    try {
		logger.info("calling getText method of JSONData class");
		jsonArray = new JSONArray(getText("http://10.0.50.57/FI_Integration/GlobalService.svc/GetBDGMSOrder_Expected/"+tokenId+"/"+employeeId+"/"+sDate+"/"+eDate));
		logger.info("exit from getText method"); 
		Customer customer;
         List<Customer> customers=new ArrayList<Customer>();
         for(int i=0;i<jsonArray.length();i++)
         {
        	customer =new Customer();
            JSONObject obj=jsonArray.getJSONObject(i);
	        customer.setProjectCode(obj.getString("PROJECT_CODE"));
	        customer.setMarketRep(obj.getString("MARKET_REP"));
	        customer.setOrdExpDate(obj.getString("ORD_EXP_DATE"));
	        customer.setProjectValue(obj.getString("PROJECT_VALUE"));
	        customer.setnProjUsdMillion(obj.getString("N_PROJ_USD_MILLION"));
	        customer.setClosePlanExists(obj.getString("CLOSE_PLAN_EXISTS"));
	        customer.setPnlAc(obj.getString("PNL_AC"));
	        customer.setCustCode(obj.getString("CUST_CODE"));
	        customer.setUnit(obj.getString("UNIT"));
	        customer.setIBU(obj.getString("IBU"));
	        customer.setRegion(obj.getString("REGION"));
	        customer.setpCAtDescription(obj.getString("P_CAT_DESCRIPTION"));
	        customer.setvProspectingStage(obj.getString("V_PROSPECTING_STAGE"));
	        customer.setFileAttachedDate(obj.getString("FILE_ATTACHED_DATE"));
	        customer.setdInitializationDate(obj.getString("D_INITIATIONDATE"));
	        customer.setOrderStatus(obj.getString("ORDERSTATUS"));
	        customer.setBidLastUpdated(obj.getString("BID_LAST_UPDATED"));
	        customers.add(customer);
	} 
         logger.info("customer data:");
         int count=0;
         for (Customer customer2 : customers) 
         {
        	 count++;
			logger.info(count+": customer data is: "+customer2);
		 }
         
               logger.info("returning customer data");
         	    return customers;
			 
	}
         catch (Exception e) {
       logger.error("webservice is not working");
	} 	
    return null;
         }
       
}
