package com.nucleus.domain;

public class Customer
{
	 private String projectCode;
	 private String marketRep;
	 private String ordExpDate;
	 private String projectValue;
	 private String nProjUsdMillion;
	 private String closePlanExists;
	 private String pnlAc;
	 private String custCode;
	 private String unit;
	 private String IBU;
	 private String region;
	 private String pCAtDescription;
	 private String vProspectingStage;
     private String fileAttachedDate;
     private String dInitializationDate;
     private String orderStatus;
     private String bidLastUpdated;
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getMarketRep() {
		return marketRep;
	}
	public void setMarketRep(String marketRep) {
		this.marketRep = marketRep;
	}
	public String getOrdExpDate() {
		return ordExpDate;
	}
	public void setOrdExpDate(String ordExpDate) {
		this.ordExpDate = ordExpDate;
	}
	public String getProjectValue() {
		return projectValue;
	}
	public void setProjectValue(String projectValue) {
		this.projectValue = projectValue;
	}
	public String getnProjUsdMillion() {
		return nProjUsdMillion;
	}
	public void setnProjUsdMillion(String nProjUsdMillion) {
		this.nProjUsdMillion = nProjUsdMillion;
	}
	public String getClosePlanExists() {
		return closePlanExists;
	}
	public void setClosePlanExists(String closePlanExists) {
		this.closePlanExists = closePlanExists;
	}
	public String getPnlAc() {
		return pnlAc;
	}
	public void setPnlAc(String pnlAc) {
		this.pnlAc = pnlAc;
	}
	public String getCustCode() {
		return custCode;
	}
	public void setCustCode(String custCode) {
		this.custCode = custCode;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getIBU() {
		return IBU;
	}
	public void setIBU(String iBU) {
		IBU = iBU;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getpCAtDescription() {
		return pCAtDescription;
	}
	public void setpCAtDescription(String pCAtDescription) {
		this.pCAtDescription = pCAtDescription;
	}
	public String getvProspectingStage() {
		return vProspectingStage;
	}
	public void setvProspectingStage(String vProspectingStage) {
		this.vProspectingStage = vProspectingStage;
	}
	public String getFileAttachedDate() {
		return fileAttachedDate;
	}
	public void setFileAttachedDate(String fileAttachedDate) {
		this.fileAttachedDate = fileAttachedDate;
	}
	public String getdInitializationDate() {
		return dInitializationDate;
	}
	public void setdInitializationDate(String dInitializationDate) {
		this.dInitializationDate = dInitializationDate;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public String getBidLastUpdated() {
		return bidLastUpdated;
	}
	public void setBidLastUpdated(String bidLastUpdated) {
		this.bidLastUpdated = bidLastUpdated;
	}
	@Override
	public String toString() {
		return "Customer [projectCode=" + projectCode + ", marketRep=" + marketRep + ", ordExpDate=" + ordExpDate
				+ ", projectValue=" + projectValue + ", nProjUsdMillion=" + nProjUsdMillion + ", closePlanExists="
				+ closePlanExists + ", pnlAc=" + pnlAc + ", custCode=" + custCode + ", unit=" + unit + ", IBU=" + IBU
				+ ", region=" + region + ", pCAtDescription=" + pCAtDescription + ", vProspectingStage="
				+ vProspectingStage + ", fileAttachedDate=" + fileAttachedDate + ", dInitializationDate="
				+ dInitializationDate + ", orderStatus=" + orderStatus + ", bidLastUpdated=" + bidLastUpdated + "]";
	}

       


}
