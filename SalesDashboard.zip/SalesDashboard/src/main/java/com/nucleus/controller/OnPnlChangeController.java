package com.nucleus.controller;


import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import com.nucleus.domain.Customer;
import com.nucleus.model.GetAccountManagerTableData;
import com.nucleus.model.GetAccountManagerTableDataImpl;
import com.nucleus.model.GetFunnelData;
import com.nucleus.model.GetFunnelDataImpl;
import com.nucleus.model.GetQuarterTableData;
import com.nucleus.model.GetQuarterTableDataImpl;



@WebServlet("/onPnlChangeController")
public class OnPnlChangeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
  private GetFunnelData getFunnelData=new GetFunnelDataImpl();
  private GetQuarterTableData getQuarterTableData=new GetQuarterTableDataImpl();
  private GetAccountManagerTableData getAccountManagerTableData=new GetAccountManagerTableDataImpl();
  private Logger logger = Logger.getLogger(OnPnlChangeController.class.getName());
  public OnPnlChangeController() {
        super();
      }
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
	logger.info("entered in doGet() method of "+getClass());
	logger.info("fetching value of pnl through dropdown");
	String pnl=request.getParameter("pnl");
	logger.info("fetched value of pnl is "+pnl);
	request.setAttribute("pnl",pnl);
	DecimalFormat two = new DecimalFormat("0.000");
	
	
	   String fy1= (String) request.getServletContext().getAttribute("fy1");
	    request.setAttribute("fy1",fy1);
	    
	   String[] fy=  (String[]) request.getServletContext().getAttribute("fy");
	   request.setAttribute("fy",fy);
	   try
	   {
	    @SuppressWarnings("unchecked")
		List<Customer> customers = (List<Customer>) request.getServletContext().getAttribute("customers");
	  

	    /***************************getting pnl**********************************************/
	    logger.info("storing list of account manager according to selected fy");
			Set<String> pnlAcs = new HashSet<String>();
			for (Customer customer : customers) 
			{
				pnlAcs.add(customer.getPnlAc());
			}
			logger.info("List of p&l:");
			for(String p:pnlAcs)
			{
				logger.info(p);
			}
			logger.info("setting list of account manager in request parameter");
			request.setAttribute("pnlAcs",pnlAcs);
	
	
		 
			 /********************************** getting funnel data*********************************************/
		logger.info("loading funnel data for current fy, so calling getFunnelOppCountAndValue(pnl,customers) method of GetFunnelData class");			
		List<Object[]> countAndValue=getFunnelData.getFunnelOppCountAndValue(pnl, customers);
		logger.info("returned from getFunnelOppCountAndValue(pnl,customers) method");
		Object[] oppCount = countAndValue.get(0);
		Object[] oppValue = countAndValue.get(1);
		int length=oppValue.length;
		String[] value=new String[length];
		for(int i=0;i<oppValue.length;i++)
		{
			 value[i]=two.format(oppValue[i]); 
		}
		logger.info("setting count and value in request parameter");
	    request.setAttribute("oppCount",oppCount);
	    request.setAttribute("oppValue",value);
	
	    /*********************getting quarter table data************************************/
	    logger.info("getting quarter wise count and value, calling getQuarterCountAndValue(fy,pnl,customers) method");
	    List<Object[]> quarterCountAndValue=getQuarterTableData.getQuarterCountAndValue(fy1, pnl, customers);
	    logger.info("returned from getQuarterCountAndValue(fy,pnl,customers) method");
	    Object[] quarterOppCount = quarterCountAndValue.get(0);
		int totalOppCount=0;
		for (Object object : quarterOppCount) {
			totalOppCount+=(Integer)object;
		}
		logger.info("total opportunity count is: "+totalOppCount);
		Object[] quarterOppValue=quarterCountAndValue.get(1);
		 Float totalOppValue=0.0f;
	    for (Object object : quarterOppValue) 
	    {
	    	totalOppValue+=(Float)object;
		}
	    String sum=two.format(totalOppValue);
	    logger.info("Total opportunity value is: "+sum);
		String[] quarterValue=new String[4];
		for(int i=0;i<quarterOppValue.length;i++)
		{
			 quarterValue[i]=two.format(quarterOppValue[i]); 
		}
		logger.info("setting quartely count and value in request parameter");
	    request.setAttribute("quarterOppCount", quarterOppCount);
	    request.setAttribute("quarterOppValue", quarterValue);
	    logger.info("setting total count and value in request parameter");
	    request.setAttribute("totalOppCount", totalOppCount);
	    request.setAttribute("totalOppValue", sum);
	    
	    
	    /***************************getting account manager table data*********************************************/
	    logger.info("getting account manager name, count and value");
	    logger.info("calling getAccountManagerCountAndValue(pnl,customers)");
	    List<Object[]> accountManagerNameCountAndValue=getAccountManagerTableData.getAccountManagerCountAndValue(pnl, customers);
	    logger.info("returned from getAccountManagerCountAndValue(pnl,customers)");
	    Object[] accountManagerName=accountManagerNameCountAndValue.get(0);
		Object[] accountManagerCount=accountManagerNameCountAndValue.get(1);
		int amsCount=0;
		for (Object object : accountManagerCount) 
		{
			amsCount+=(Integer)object;
		}
		Object[] accountManagerValue=accountManagerNameCountAndValue.get(2);
		float amsValue=0.000f;
		for (Object object : accountManagerValue) {
			amsValue+=(Float)object;
		}
		String managerValue=two.format(amsValue);
		int l=accountManagerValue.length;
		String[] amValue=new String[l];
		
		for(int i=0;i<accountManagerValue.length;i++)
		{
			 amValue[i]=two.format(accountManagerValue[i]); 
		}
		
		   logger.info("setting account manager name, count ,value ,total count and total value in request parameter");
	        request.setAttribute("accountManagerName", accountManagerName);
		    request.setAttribute("accountManagerCount", accountManagerCount);
		    request.setAttribute("accountManagerValue", amValue);
		    request.setAttribute("amsCount", amsCount);
		    request.setAttribute("amsValue", managerValue);
		    
		  /*******************  data table links for funnel*****************************/
		    String[] spancoLink = { "funnelController?action=Suspect", "funnelController?action=Prospect",
					"funnelController?action=Approach", "funnelController?action=Negotiation",
					"funnelController?action=Close", "funnelController?action=Order" };
		    request.setAttribute("spancoLink",spancoLink );
		   
		    /****************************data table links for Quarterly table*************************************/
		    String[] quarterValues={"funnelController?action=pnl1","funnelController?action=pnl2","funnelController?action=pnl3","funnelController?action=pnl4"};
		    request.setAttribute("quarterValues", quarterValues);
		    
		    String valueQuarter="funnelController?action=qTotalPnl";
		    request.setAttribute("valueQuarter", valueQuarter);
		    /********************* data table links for account manager table****************************/
		    String managerName = "funnelController?action=amsTable";
		    request.setAttribute("managerName", managerName);
		    request.getRequestDispatcher("WEB-INF/salesdashboard.jsp").forward(request, response); 
	   }
	   catch(Exception e)
	   {
		   logger.error("list of customer is empty, because web service is not working");
		   request.getRequestDispatcher("WEB-INF/error500.jsp").forward(request, response);
	   }
     
}
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     {
			doGet(request, response);
     }
     
     

}
