package com.nucleus.controller;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import com.nucleus.domain.Customer;
import com.nucleus.model.DataTableModel;
import com.nucleus.model.DataTableModelImpl;


@WebServlet("/funnelController")
public class FunnelController extends HttpServlet {
	private Logger logger = Logger.getLogger(FunnelController.class.getName());
	private static final long serialVersionUID = 1L;
   private DataTableModel dataTableModel=new DataTableModelImpl();

  public FunnelController() {
        super();
      }
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
	logger.info("entered in doGet method of "+logger.getName());
	String action=request.getParameter("action");
	logger.info("fetched value of parameter 'action' is "+action);
	logger.info("fetching the list pof customer using servlet context ");
	try
	{
		@SuppressWarnings("unchecked")
		List<Customer> customers = (List<Customer>) request.getServletContext().getAttribute("customers");
		List<String[]> onClickData=null;
		if(action.equalsIgnoreCase("Suspect")||action.equalsIgnoreCase("Prospect")||action.equalsIgnoreCase("Approach")||action.equalsIgnoreCase("Negotiation")||action.equalsIgnoreCase("Close")||action.equalsIgnoreCase("Order"))
		{
			String pnl=request.getParameter("pnl");
			if(pnl.equalsIgnoreCase("all"))
			{
				logger.info("calling getDataStageWise(action,customer) method");
			    onClickData=dataTableModel.getDataStageWise(action, customers);
			}
			else
			{
				logger.info("calling getPnlDataStageWise(pnl,action,customer) method");
				onClickData=dataTableModel.getPnlDataStageWise(pnl,action,customers);
			}
		}

		else if(action.equalsIgnoreCase("1")||action.equalsIgnoreCase("2")||action.equalsIgnoreCase("3")||action.equalsIgnoreCase("4"))
		{
			String fy=request.getParameter("fy");
			logger.info("calling getDataQuartely(fy,action,customers) method");             
			onClickData=dataTableModel.getDataQuartely(fy,action, customers);               
		}                                                                                   
		else if(action.equalsIgnoreCase("qTotal"))                                          
		{                                                                                   
			logger.info("calling getDataQuartely(fy,customers) method");                    
			onClickData=dataTableModel.getDataQuartely(customers);                          
		}                                                                                   
		else if(action.equalsIgnoreCase("amsTotal"))                                        
		{                                                                                   
			String pnl=request.getParameter("pnl");                                         
			if(pnl.equalsIgnoreCase("all"))
			{
				logger.info("calling getAccountManagerWiseTableData(customers) method");
			onClickData=dataTableModel.getAccountManagerWiseTableData(customers);
			}
			else
			{
				logger.info("calling getAccountManagerWiseTableData(pnl,customers) method");
			onClickData=dataTableModel.getAccountManagerWiseTableDataPnl(pnl,customers);
			}
			
		}
		else if(action.equalsIgnoreCase("pnl1")||action.equalsIgnoreCase("pnl2")||action.equalsIgnoreCase("pnl3")||action.equalsIgnoreCase("pnl4"))
		{
			String fy=request.getParameter("fy");
			String pnl=request.getParameter("pnl");
			logger.info("calling getPnlDataQuartely(action,fy,pnl,customers) method");
			onClickData=dataTableModel.getPnlDataQuartely(action,fy,pnl, customers);
		}
		else if(action.equalsIgnoreCase("qTotalPnl"))
		{
	        String pnl=request.getParameter("pnl");
	        logger.info("calling getDataQuartelyPnl(fy,pnl,customers) method");
			onClickData=dataTableModel.getDataQuartelyPnl(pnl, customers);
		}
		else if(action.equalsIgnoreCase("amsTable"))
		{
			String pnl=request.getParameter("pnl");
			String name=request.getParameter("name");
			if(pnl.equalsIgnoreCase("all"))
			{
			logger.info("calling getAccountManagerWiseTableData(name,customers) method");
			onClickData=dataTableModel.getAccountManagerWiseTableData(name, customers);
			}
			else
			{
				logger.info("calling getAccountManagerWiseTableDataPnl(name,pnl,customers)");
				onClickData=dataTableModel.getAccountManagerWiseTableDataPnl(name, pnl, customers);
			}
		}
		request.setAttribute("onClickData", onClickData);
		request.getRequestDispatcher("WEB-INF/allCustomers.jsp").forward(request, response); 
	}
	catch(Exception e)
	{
		logger.error("list of customer is empty because webservice is not working");
		 request.getRequestDispatcher("WEB-INF/error500.jsp").forward(request, response);
		
	}
	
}
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request, response);
	}

}
