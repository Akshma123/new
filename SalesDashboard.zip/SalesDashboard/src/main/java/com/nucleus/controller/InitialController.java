package com.nucleus.controller;


import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import com.nucleus.domain.Customer;
import com.nucleus.model.GetAccountManagerTableData;
import com.nucleus.model.GetAccountManagerTableDataImpl;
import com.nucleus.model.GetFunnelData;
import com.nucleus.model.GetFunnelDataImpl;
import com.nucleus.model.GetQuarterTableData;
import com.nucleus.model.GetQuarterTableDataImpl;
import com.nucleus.webservice.JSONData;

@WebServlet("/initialController")
public class InitialController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  private JSONData jsonData=new JSONData();
  GetFunnelData getFunnelData=new GetFunnelDataImpl();
  GetQuarterTableData getQuarterTableData=new GetQuarterTableDataImpl();
  GetAccountManagerTableData getAccountManagerTableData=new GetAccountManagerTableDataImpl();
  private Logger logger = Logger.getLogger(InitialController.class.getName());
  public InitialController() {
        super();
      }
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
	/******************setting fy for dropdown******************/
	
	
	logger.info("entered in doGet method of initial controller");
	logger.info("storing current fy and next five years in list");
	String[] fy=new String[6];
    Calendar cal = Calendar.getInstance();
    cal.setTimeZone(TimeZone.getTimeZone("GMT"));
    for(int i=0;i<6;i++)
    {
    int year=cal.get(Calendar.YEAR);
    cal.add(Calendar.YEAR, 1);
    String y=year+"-"+cal.get(Calendar.YEAR);
     fy[i]=y;
    }
    logger.info("current fy value is: "+fy[0]);
    logger.info("current fy and next five years values are: ");
    for(String year:fy)
    {
    logger.info(year);
    }
    logger.info("setting fy and list of fy in request parameter");
    request.setAttribute("fy",fy);
    request.setAttribute("fy1",fy[0]);
    
    
    /********************** getting current year opportunities data********************************/
    logger.info("getting customer data according to current fy, so calling getCustomers(fy) method of JsonData class");
    try
    {
    	String empId=(String) request.getSession().getAttribute("employee_id");
        String tokenId=(String) request.getSession().getAttribute("token_id");
        if(empId==null||tokenId==null)
    {
    	logger.error("emp id or token id is null");
    	 request.getRequestDispatcher("WEB-INF/wrongCredentials.jsp").forward(request, response);
    }
    else
    {
    	  
    //List<Customer> customersData=jsonData.getCustomers("2015-"+fy[5],empId,tokenId);
    //if(customersData.size()==0)
    	if(1==0)
    	 {
    		    logger.error("Customer list is empty");	
    		    request.getRequestDispatcher("WEB-INF/emptyListError.jsp").forward(request, response);
    	 }
    else
    	{
    List<Customer> customers=jsonData.getCustomers(fy[0],empId,tokenId);
    logger.info("returned from getCustomers(fy) method");
    logger.info("setting list of customer in servlet context");
    ServletContext servletContext = request.getServletContext();
	servletContext.setAttribute("customers", customers);
	logger.info("setting current fy and list of fy in servletcontext");
	servletContext.setAttribute("fy1",fy[0]);
	servletContext.setAttribute("fy",fy);
	
	/***************************getting pnl**********************************************/
	logger.info("storing list of account manager according to current fy");
	Set<String> pnlAcs = new LinkedHashSet<String>();
	
	for (Customer customer : customers) 
	{
		pnlAcs.add(customer.getPnlAc());
		
	}
	logger.info("List of p&l:");
	for(String p:pnlAcs)
	{
		logger.info(p);
	}
	logger.info("setting list of account manager in request parameter");
	request.setAttribute("pnlAcs",pnlAcs);
	
	 DecimalFormat two = new DecimalFormat("0.000");
	 /********************************** getting funnel data*********************************************/
	logger.info("loading funnel data for current fy, so calling getFunnelOppCountAndValue(customers) method of GetFunnelData class");
	List<Object[]> countAndValue=getFunnelData.getFunnelOppCountAndValue(customers);
	logger.info("returned from getFunnelOppCountAndValue(customers) method");
	Object[] oppCount = countAndValue.get(0);
	Object[] oppValue = countAndValue.get(1);
	int length=oppValue.length;
	String[] value=new String[length];
	for(int i=0;i<oppValue.length;i++)
	{
		 value[i]=two.format(oppValue[i]); 
	}
	logger.info("setting count and value in request parameter");
    request.setAttribute("oppCount",oppCount);
    request.setAttribute("oppValue",value);
    
    
    
    /*********************getting quarter table data************************************/
    logger.info("getting quarter wise count and value, calling getQuarterCountAndValue(fy,customers) method");
    List<Object[]> quarterCountAndValue=getQuarterTableData.getQuarterCountAndValue(fy[0], customers);
    logger.info("returned from getQuarterCountAndValue(fy,customers) method");
    Object[] quarterOppCount = quarterCountAndValue.get(0);
	int totalOppCount=0;
	for (Object object : quarterOppCount) {
		totalOppCount+=(Integer)object;
	}
	logger.info("total opportunity count is: "+totalOppCount);
	Object[] quarterOppValue=quarterCountAndValue.get(1);
	 Float totalOppValue=0.0f;
    for (Object object : quarterOppValue) 
    {
    	totalOppValue+=(Float)object;
	}
    String sum=two.format(totalOppValue);
    logger.info("Total opportunity value is: "+sum);
	String[] quarterValue=new String[4];
	for(int i=0;i<quarterOppValue.length;i++)
	{
		 quarterValue[i]=two.format(quarterOppValue[i]); 
	}
   
	logger.info("setting quartely count and value in request parameter");
    request.setAttribute("quarterOppCount", quarterOppCount);
    request.setAttribute("quarterOppValue", quarterValue);
    logger.info("setting total count and value in request parameter");
    request.setAttribute("totalOppCount", totalOppCount);
    request.setAttribute("totalOppValue", sum);
    
    
    /*******************************getting account manager table data*********************************************/
    logger.info("getting account manager name, count and value");
    logger.info("calling getAccountManagerCountAndValue(customers)");
    List<Object[]> accountManagerNameCountAndValue=getAccountManagerTableData.getAccountManagerCountAndValue(customers);
    logger.info("returned from getAccountManagerCountAndValue(customers)");
    Object[] accountManagerName=accountManagerNameCountAndValue.get(0);
	Object[] accountManagerCount=accountManagerNameCountAndValue.get(1);
	int amsCount=0;
	for (Object object : accountManagerCount) 
	{
		amsCount+=(Integer)object;
	}
	Object[] accountManagerValue=accountManagerNameCountAndValue.get(2);
	float amsValue=0.000f;
	for (Object object : accountManagerValue) {
		amsValue+=(Float)object;
	}
	String managerValue=two.format(amsValue);
	int l=accountManagerValue.length;
	String[] amValue=new String[l];
	
	for(int i=0;i<accountManagerValue.length;i++)
	{
		 amValue[i]=two.format(accountManagerValue[i]); 
	}
	
          logger.info("setting account manager name, count ,value ,total count and total value in request parameter");
        request.setAttribute("accountManagerName", accountManagerName);
	    request.setAttribute("accountManagerCount", accountManagerCount);
	    request.setAttribute("accountManagerValue", amValue);
	    request.setAttribute("amsCount", amsCount);
	    request.setAttribute("amsValue", managerValue);
	    
	
	    
	    /*******************  data table links for funnel*****************************/
	    String[] spancoLink = { "funnelController?action=Suspect", "funnelController?action=Prospect",
				"funnelController?action=Approach", "funnelController?action=Negotiation",
				"funnelController?action=Close", "funnelController?action=Order" };
	    request.setAttribute("spancoLink",spancoLink );
	    
	   
	    request.setAttribute("pnl","All");
	    
	    /****************************data table links for Quarterly table*************************************/
	    String[] quarterValues={"funnelController?action=1","funnelController?action=2","funnelController?action=3","funnelController?action=4"};
	    request.setAttribute("quarterValues", quarterValues);
	    
	    String valueQuarter="funnelController?action=qTotal";
	    request.setAttribute("valueQuarter", valueQuarter);
	    /********************* data table links for account manager table****************************/
	    String managerName = "funnelController?action=amsTable";
	    request.setAttribute("managerName", managerName);
	    request.getRequestDispatcher("WEB-INF/salesdashboard.jsp").forward(request, response);
    	 }
    }
    }
    catch(Exception e)
    {   
    	logger.error("Customer list is empty because webservice is not working");
    	 request.getRequestDispatcher("WEB-INF/error500.jsp").forward(request, response);
    }
    
        
}
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     {
			doGet(request, response);
     }
     
     

}
