package com.nucleus.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import com.nucleus.domain.Customer;

public class DataTableModelImpl implements DataTableModel
{
	private Logger logger = Logger.getLogger(DataTableModelImpl.class.getName());
	public List<String[]> getDataStageWise(String stage,List<Customer> customers)
	{
		logger.info("entered in getDataStageWise(stage,customers)");
		List<String[]>  stageWiseCustomerData=new ArrayList<String[]>();
    	String[] stageData;
		for(Customer customer:customers)
		{
			if(customer.getvProspectingStage().equalsIgnoreCase(stage))
					{
				stageData=new String[10];
				stageData[0]=customer.getCustCode();
				stageData[1]=customer.getProjectCode();
				stageData[2]=customer.getMarketRep();
				stageData[3]=customer.getdInitializationDate();
				stageData[4]=customer.getOrdExpDate();
				stageData[5]=customer.getvProspectingStage();
				stageData[6]=customer.getOrderStatus();
				stageData[7]=customer.getnProjUsdMillion();
				stageData[8]=customer.getBidLastUpdated();
				stageData[9]=customer.getFileAttachedDate();
				stageWiseCustomerData.add(stageData);
					}
		}
		logger.info("returning customer data stage(SPANCO) wise");
		return stageWiseCustomerData;
}
	
	
	  public List<String[]> getDataQuartely(String fy, String quarter,List<Customer> customers)
	    {
		  logger.info("entered in getDataQuartely(fy,quarter,customers)");
	    	 String[] date=fy.split("-");
	    	 SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
	 	     Date qStartDate=null, qEndDate=null;
	 	      if(quarter.equalsIgnoreCase("1"))
	 	      {
	 	    	 try {
					qStartDate = sdf.parse(date[0]+"-4-1");
					qEndDate= sdf.parse(date[0]+"-6-30");
				} catch (ParseException e) {
					e.printStackTrace();
				}
	 	      }
	 	      else if(quarter.equalsIgnoreCase("2"))
	 	      {
	 	    	 try {
					qStartDate = sdf.parse(date[0]+"-7-1");
					 qEndDate= sdf.parse(date[0]+"-9-30");
				} catch (ParseException e) {

					e.printStackTrace();
				}    
	 	      }
	 	      else if(quarter.equalsIgnoreCase("3"))
	 	      {
	 	    	 try {
	 	    	    qStartDate = sdf.parse(date[0]+"-10-1");
	    		    qEndDate= sdf.parse(date[0]+"-12-31");
	 			} catch (ParseException e) {
	 				e.printStackTrace();
	 			}    
	 	      }
	 	      else
	 	      {
	 	    	 try {
	 	    		  qStartDate = sdf.parse(date[1]+"-1-1");
		    		    qEndDate= sdf.parse(date[1]+"-3-31");
	 			} catch (ParseException e) {
	 				e.printStackTrace();
	 			}    
	 	      }
	 	  	List<String[]>  quartelyCustomerData=new ArrayList<String[]>();
	    	String[] quartelyData;
	    	for(Customer customer:customers)
	    	{
	    		String date1=customer.getOrdExpDate();
				String[] dates=date1.split("/");
				String date2="";
				date2=date2.concat(dates[2].substring(0,4));
				Date expDate=null;
					try {
						expDate = sdf.parse(date2+"-"+dates[0]+"-"+dates[1]);
						 if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
						  {
		    		quartelyData=new String[10];
		    		quartelyData[0]=customer.getCustCode();
		    		quartelyData[1]=customer.getProjectCode();
		    		quartelyData[2]=customer.getMarketRep();
		    		quartelyData[3]=customer.getdInitializationDate();
		    		quartelyData[4]=customer.getOrdExpDate();
		    		quartelyData[5]=customer.getvProspectingStage();
		    		quartelyData[6]=customer.getOrderStatus();
		    	    quartelyData[7]=customer.getnProjUsdMillion();
		    		quartelyData[8]=customer.getBidLastUpdated();
		    		quartelyData[9]=customer.getFileAttachedDate();
		    		quartelyCustomerData.add(quartelyData);
		    	}
					} catch (ParseException e) {
						e.printStackTrace();
					}
					}
	    	logger.info("returning quarter wise customer data");
	    	return quartelyCustomerData;
	}
	  
	  
	  public List<String[]> getAccountManagerWiseTableData(String accountManagerName,List<Customer> customers)
	  {
		  logger.info("entered in getAccountManagerWiseTableData(accountManagerName,customers)");
		    List<String[]>  accountManagerWiseData=new ArrayList<String[]>();
	     	String[] accountManagerData;
			for(Customer customer:customers)
			{
			
				if(customer.getMarketRep().equalsIgnoreCase(accountManagerName))
						{
				
					accountManagerData=new String[10];
					accountManagerData[0]=customer.getCustCode();
					accountManagerData[1]=customer.getProjectCode();
					accountManagerData[2]=customer.getMarketRep();
					accountManagerData[3]=customer.getdInitializationDate();
					accountManagerData[4]=customer.getOrdExpDate();
					accountManagerData[5]=customer.getvProspectingStage();
					accountManagerData[6]=customer.getOrderStatus();
					accountManagerData[7]=customer.getnProjUsdMillion();
					accountManagerData[8]=customer.getBidLastUpdated();
					accountManagerData[9]=customer.getFileAttachedDate();
					accountManagerWiseData.add(accountManagerData);
						}
			}
			return accountManagerWiseData;
	  }


	@Override
	public List<String[]> getDataQuartely(List<Customer> customers) {
		logger.info("entered in getDataQuartely(customers) method of "+getClass());
		   List<String[]>  accountManagerWiseData=new ArrayList<String[]>();
	     	String[] quarterData;
		for(Customer customer:customers)
    	{
			quarterData=new String[10];
			quarterData[0]=customer.getCustCode();
			quarterData[1]=customer.getProjectCode();
			quarterData[2]=customer.getMarketRep();
			quarterData[3]=customer.getdInitializationDate();
			quarterData[4]=customer.getOrdExpDate();
			quarterData[5]=customer.getvProspectingStage();
			quarterData[6]=customer.getOrderStatus();
			quarterData[7]=customer.getnProjUsdMillion();
			quarterData[8]=customer.getBidLastUpdated();
			quarterData[9]=customer.getFileAttachedDate();
			accountManagerWiseData.add(quarterData);
    	}
		logger.info("returning quarter table data");
		return accountManagerWiseData;
	}


	@Override
	public List<String[]> getAccountManagerWiseTableData(List<Customer> customers) {
		logger.info("entered in getAccountManagerWiseTableData(customers)");
		  List<String[]>  accountManagerWiseData=new ArrayList<String[]>();
	     	String[] accountManagerData;
			for(Customer customer:customers)
			{
				accountManagerData=new String[10];
				accountManagerData[0]=customer.getCustCode();
				accountManagerData[1]=customer.getProjectCode();
				accountManagerData[2]=customer.getMarketRep();
				accountManagerData[3]=customer.getdInitializationDate();
				accountManagerData[4]=customer.getOrdExpDate();
				accountManagerData[5]=customer.getvProspectingStage();
				accountManagerData[6]=customer.getOrderStatus();
				accountManagerData[7]=customer.getnProjUsdMillion();
				accountManagerData[8]=customer.getBidLastUpdated();
				accountManagerData[9]=customer.getFileAttachedDate();
					accountManagerWiseData.add(accountManagerData);
			}
			logger.info("returning account manager table data");
			return accountManagerWiseData;
	}


	@Override
	public List<String[]> getDataQuartelyPnl(String pnl, List<Customer> customers)
	{
		logger.info("entered in getDataQuartelyPnl(pnl,customers) method of "+getClass());
		  List<String[]>  getQuarterlyData=new ArrayList<String[]>();
	     	String[] quarterData;
			for(Customer customer:customers)
			{
				if(customer.getPnlAc().equalsIgnoreCase(pnl))
				{
					quarterData=new String[10];
					quarterData[0]=customer.getCustCode();
					quarterData[1]=customer.getProjectCode();
					quarterData[2]=customer.getMarketRep();
					quarterData[3]=customer.getdInitializationDate();
					quarterData[4]=customer.getOrdExpDate();
					quarterData[5]=customer.getvProspectingStage();
					quarterData[6]=customer.getOrderStatus();
					quarterData[7]=customer.getnProjUsdMillion();
					quarterData[8]=customer.getBidLastUpdated();
					quarterData[9]=customer.getFileAttachedDate();
					getQuarterlyData.add(quarterData);
			}
					}
			logger.info("returning quarter table data");
			return getQuarterlyData;
	}


	@Override
	public List<String[]> getAccountManagerWiseTableDataPnl(String pnl, List<Customer> customers) {
		logger.info("entered in getAccountManagerWiseTableDataPnl(pnl,customers) method of "+getClass());
		List<String[]>  accountManagerWiseData=new ArrayList<String[]>();
     	String[] accountManagerData;
		for(Customer customer:customers)
		{
			if(customer.getPnlAc().equalsIgnoreCase(pnl))
			{
				accountManagerData=new String[10];
				accountManagerData[0]=customer.getCustCode();
				accountManagerData[1]=customer.getProjectCode();
				accountManagerData[2]=customer.getMarketRep();
				accountManagerData[3]=customer.getdInitializationDate();
				accountManagerData[4]=customer.getOrdExpDate();
				accountManagerData[5]=customer.getvProspectingStage();
				accountManagerData[6]=customer.getOrderStatus();
				accountManagerData[7]=customer.getnProjUsdMillion();
				accountManagerData[8]=customer.getBidLastUpdated();
				accountManagerData[9]=customer.getFileAttachedDate();
				
				accountManagerWiseData.add(accountManagerData);
		}
		}
		logger.info("returning account manager table data");
		return accountManagerWiseData;
	}

	public List<String[]> getAccountManagerWiseTableDataPnl(String name,String pnl, List<Customer> customers) {
		logger.info("entered in getAccountManagerWiseTableDataPnl(name,pnl,customers) method of "+getClass());
		List<String[]>  accountManagerWiseData=new ArrayList<String[]>();
     	String[] stageData;
		for(Customer customer:customers)
		{
			if(customer.getMarketRep().equalsIgnoreCase(name))
			{
			if(customer.getPnlAc().equalsIgnoreCase(pnl))
			{
				stageData=new String[10];
				stageData[0]=customer.getCustCode();
				stageData[1]=customer.getProjectCode();
				stageData[2]=customer.getMarketRep();
				stageData[3]=customer.getdInitializationDate();
				stageData[4]=customer.getOrdExpDate();
				stageData[5]=customer.getvProspectingStage();
				stageData[6]=customer.getOrderStatus();
				stageData[7]=customer.getnProjUsdMillion();
				stageData[8]=customer.getBidLastUpdated();
				stageData[9]=customer.getFileAttachedDate();
				accountManagerWiseData.add(stageData);
		}
		}}
		logger.info("returning account manager table data");
		return accountManagerWiseData;
	}
	

	@Override
	public List<String[]> getPnlDataQuartely(String quarter, String fy, String pnl, List<Customer> customers) {
		logger.info("entered in getPnlDataQuartely(quarter,fy,pnl,customers) method of "+getClass());
		 String[] date=fy.split("-");
    	 SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
 	     Date qStartDate=null, qEndDate=null;
 	      if(quarter.equalsIgnoreCase("pnl1"))
 	      {
 	    	 try {
				qStartDate = sdf.parse(date[0]+"-4-1");
				qEndDate= sdf.parse(date[0]+"-6-30");
			} catch (ParseException e) {
				e.printStackTrace();
			}
 	      }
 	      else if(quarter.equalsIgnoreCase("pnl2"))
 	      {
 	    	 try {
				qStartDate = sdf.parse(date[0]+"-7-1");
				 qEndDate= sdf.parse(date[0]+"-9-30");
			} catch (ParseException e) {

				e.printStackTrace();
			}    
 	      }
 	      else if(quarter.equalsIgnoreCase("pnl3"))
 	      {
 	    	 try {
 	    	    qStartDate = sdf.parse(date[0]+"-10-1");
    		    qEndDate= sdf.parse(date[0]+"-12-31");
 			} catch (ParseException e) {
 				e.printStackTrace();
 			}    
 	      }
 	      else
 	      {
 	    	 try {
 	    		  qStartDate = sdf.parse(date[1]+"-1-1");
	    		    qEndDate= sdf.parse(date[1]+"-3-31");
 			} catch (ParseException e) {
 				e.printStackTrace();
 			}    
 	      }
    	List<String[]>  quartelyCustomerData=new ArrayList<String[]>();
    	String[] quartelyData;
    	for(Customer customer:customers)
    	{
    		String date1=customer.getOrdExpDate();
			String[] dates=date1.split("/");
			String date2="";
			date2=date2.concat(dates[2].substring(0,4));
			Date expDate=null;
				try {
					expDate = sdf.parse(date2+"-"+dates[0]+"-"+dates[1]);
					 if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
					  {
						 if(customer.getPnlAc().equalsIgnoreCase(pnl))
						 {
	    		quartelyData=new String[10];
	    		quartelyData[0]=customer.getCustCode();
	    		quartelyData[1]=customer.getProjectCode();
	    		quartelyData[2]=customer.getMarketRep();
	    		quartelyData[3]=customer.getdInitializationDate();
	    		quartelyData[4]=customer.getOrdExpDate();
	    		quartelyData[5]=customer.getvProspectingStage();
	    		quartelyData[6]=customer.getOrderStatus();
	    	    quartelyData[7]=customer.getnProjUsdMillion();
	    		quartelyData[8]=customer.getBidLastUpdated();
	    		quartelyData[9]=customer.getFileAttachedDate();
	    		quartelyCustomerData.add(quartelyData);
	    	}}
				} catch (ParseException e) {
					e.printStackTrace();
				}
				}
    	logger.info("returning quartely customer data");
    	return quartelyCustomerData;
	}


	@Override
	public List<String[]> getPnlDataStageWise(String pnl, String stage, List<Customer> customers) {
		logger.info("entered in getPnlDataStageWise(pnl,stage,customers)");
		List<String[]>  stageWiseCustomerData=new ArrayList<String[]>();
    	String[] stageData;
		for(Customer customer:customers)
		{
			if(customer.getPnlAc().equalsIgnoreCase(pnl))
			{
			if(customer.getvProspectingStage().equalsIgnoreCase(stage))
					{
				stageData=new String[10];
				stageData[0]=customer.getCustCode();
				stageData[1]=customer.getProjectCode();
				stageData[2]=customer.getMarketRep();
				stageData[3]=customer.getdInitializationDate();
				stageData[4]=customer.getOrdExpDate();
				stageData[5]=customer.getvProspectingStage();
				stageData[6]=customer.getOrderStatus();
				stageData[7]=customer.getnProjUsdMillion();
				stageData[8]=customer.getBidLastUpdated();
				stageData[9]=customer.getFileAttachedDate();
				stageWiseCustomerData.add(stageData);
					}}
		}
		logger.info("returning stage wise data according to pnl and stage");
		return stageWiseCustomerData;
	} 
}
