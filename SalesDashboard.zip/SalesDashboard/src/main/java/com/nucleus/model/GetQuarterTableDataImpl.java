package com.nucleus.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import com.nucleus.domain.Customer;

public class GetQuarterTableDataImpl implements GetQuarterTableData
{
	 private Logger logger = Logger.getLogger(GetQuarterTableDataImpl.class.getName());
	public List<Object[]> getQuarterCountAndValue(String fy, List<Customer> customers)
	{
		logger.info("entered in getQuarterCountAndValue(fy,customers) method of "+getClass());
		 String[] date=fy.split("-");
		 SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
 	     Date qStartDate=null, qEndDate=null;
 	     List<Object[]> countAndValue=new ArrayList<Object[]>(); 
 	    Integer[] count=new Integer[4];
		for(int i=0;i<4;i++)
			count[i]=0;
		Float[] value=new Float[4];
		for(int i=0;i<4;i++)
			value[i]=0.0f;
		
		for(Customer customer:customers)
		{
			String date1=customer.getOrdExpDate();
			String[] dates=date1.split("/");
			String date2="";
			date2=date2.concat(dates[2].substring(0,4));
			Date expDate=null;
			try {
				qStartDate = sdf.parse(date[0]+"-4-1");
    		    qEndDate= sdf.parse(date[0]+"-6-30");
				expDate = sdf.parse(date2+"-"+dates[0]+"-"+dates[1]);
				   if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
				  {
				    count[0]++;
					value[0]+=Float.parseFloat(customer.getnProjUsdMillion());
				  }
				     qStartDate = sdf.parse(date[0]+"-7-1");
	    		    qEndDate= sdf.parse(date[0]+"-9-30");
	    		    if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
	   				  {
	    		    	  count[1]++;
	    		    		value[1]+=Float.parseFloat(customer.getnProjUsdMillion());
	   				  }  
	    		    qStartDate = sdf.parse(date[0]+"-10-1");
	    		    qEndDate= sdf.parse(date[0]+"-12-31");
	    		    if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
	   				  {
	    		    	  count[2]++;
	    		    		value[2]+=Float.parseFloat(customer.getnProjUsdMillion());
	   				  }   
	    		    qStartDate = sdf.parse(date[1]+"-1-1");
	    		    qEndDate= sdf.parse(date[1]+"-3-31");
	    		    if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
	   				  {
	    		    	    count[3]++;
	    		    		value[3]+=Float.parseFloat(customer.getnProjUsdMillion());
	   				  }  
			}
			catch(Exception e)
			{
				
			}
		}
		logger.info("quarter wise count:");
		for(Integer c:count)
		{
			logger.info(c);
		}
		logger.info("quarter wise value:");
		for(Integer v:count)
		{
			logger.info(v);
		}
		
			countAndValue.add(count);
			countAndValue.add(value);
			logger.info("returning count and value");
			return countAndValue;
	}
	
	
	public List<Object[]> getQuarterCountAndValue(String fy, String pnl, List<Customer> customers) {
    logger.info("entered in getQuarterCountAndValue(fy,pnl,customers) method of "+getClass());
		 String[] date=fy.split("-");
		 SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
 	     Date qStartDate=null, qEndDate=null;
 	    List<Object[]> countAndValue=new ArrayList<Object[]>();
 	    
 	    Integer[] count=new Integer[4];
		for(int i=0;i<4;i++)
			count[i]=0;
		Float[] value=new Float[4];
		for(int i=0;i<4;i++)
			value[i]=0.0f;
		
		for(Customer customer:customers)
		{
			if(customer.getPnlAc().equalsIgnoreCase(pnl))
            {
			String date1=customer.getOrdExpDate();
			String[] dates=date1.split("/");
			String date2="";
			date2=date2.concat(dates[2].substring(0,4));
			Date expDate=null;
			try {
				qStartDate = sdf.parse(date[0]+"-4-1");
    		    qEndDate= sdf.parse(date[0]+"-6-30");
				expDate = sdf.parse(date2+"-"+dates[0]+"-"+dates[1]);
				   if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
				  {
				    count[0]++;
					value[0]+=Float.parseFloat(customer.getnProjUsdMillion());
				  }
				     qStartDate = sdf.parse(date[0]+"-7-1");
	    		    qEndDate= sdf.parse(date[0]+"-9-30");
	    		    if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
	   				  {
	    		    	  count[1]++;
	    		    		value[1]+=Float.parseFloat(customer.getnProjUsdMillion());
	   				  }  
	    		    qStartDate = sdf.parse(date[0]+"-10-1");
	    		    qEndDate= sdf.parse(date[0]+"-12-31");
	    		    if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
	   				  {
	    		    	  count[2]++;
	    		    		value[2]+=Float.parseFloat(customer.getnProjUsdMillion());
	   				  }   
	    		    qStartDate = sdf.parse(date[1]+"-1-1");
	    		    qEndDate= sdf.parse(date[1]+"-3-31");
	    		    if((expDate.after(qStartDate)&& expDate.before(qEndDate))||expDate.equals(qStartDate)||expDate.equals(qEndDate))
	   				  {
	    		    	    count[3]++;
	    		    		value[3]+=Float.parseFloat(customer.getnProjUsdMillion());
	   				  }  
			}
			catch(Exception e)
			{
			   	
			}
		}}
		logger.info("quarter wise count:");
		for(Integer c:count)
		{
			logger.info(c);
		}
		logger.info("quarter wise value:");
		for(Integer v:count)
		{
			logger.info(v);
		}
			countAndValue.add(count);
			countAndValue.add(value);
             logger.info("returning count and value according to pnl and fy");
			return countAndValue;
	}
}
