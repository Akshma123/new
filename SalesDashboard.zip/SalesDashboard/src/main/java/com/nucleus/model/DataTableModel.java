package com.nucleus.model;

import java.util.List;

import com.nucleus.domain.Customer;

public interface DataTableModel {
	public List<String[]> getDataStageWise(String stage,List<Customer> customers);
	public List<String[]> getPnlDataStageWise(String pnl,String stage,List<Customer> customers);
	public List<String[]> getDataQuartely(String fy, String quarter,List<Customer> customers);
	public List<String[]> getDataQuartely(List<Customer> customers);
	public List<String[]> getDataQuartelyPnl(String pnl,List<Customer> customers);
	public List<String[]> getPnlDataQuartely(String action,String fy,String pnl,List<Customer> customers);
	public List<String[]> getAccountManagerWiseTableData(String accountManagerName,List<Customer> customers);
    public List<String[]> getAccountManagerWiseTableDataPnl(String pnl,List<Customer> customers);
	public List<String[]> getAccountManagerWiseTableData(List<Customer> customers);
	public List<String[]> getAccountManagerWiseTableDataPnl(String name,String pnl, List<Customer> customers);
}
