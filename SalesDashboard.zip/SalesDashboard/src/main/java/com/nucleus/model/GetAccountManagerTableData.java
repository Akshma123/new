package com.nucleus.model;

import java.util.List;

import com.nucleus.domain.Customer;

public interface GetAccountManagerTableData {
	public List<Object[]> getAccountManagerCountAndValue(List<Customer> customers);
	public List<Object[]> getAccountManagerCountAndValue(String pnl, List<Customer> customers);
}
