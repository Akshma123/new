package com.nucleus.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.nucleus.controller.InitialController;
import com.nucleus.domain.Customer;


public class GetFunnelDataImpl implements GetFunnelData
{
	 private Logger logger = Logger.getLogger(InitialController.class.getName());
	public List<Object[]> getFunnelOppCountAndValue(List<Customer> customers)
	{
		logger.info("entered in getFunnelOppCountAndValue(customers)");
		Integer[] spanco=new Integer[6];
		for(int i=0;i<6;i++)
			spanco[i]=0;
		Float[] value=new Float[6];
		for(int i=0;i<6;i++)
			value[i]=0.0f;
		List<Object[]> countAndValue=new ArrayList<Object[]>(); 
		for(Customer customer:customers)
		{
			if(customer.getvProspectingStage().equalsIgnoreCase("Suspect"))
			{
				spanco[0]++;
				value[0]+=Float.parseFloat(customer.getnProjUsdMillion());
			}
			if(customer.getvProspectingStage().equalsIgnoreCase("Prospect"))
			{
				spanco[1]++;
		    	value[1]+=Float.parseFloat(customer.getnProjUsdMillion());
			}
			if(customer.getvProspectingStage().equalsIgnoreCase("Approach"))
			{
				spanco[2]++;
				value[2]+=Float.parseFloat(customer.getnProjUsdMillion());
			}
			if(customer.getvProspectingStage().equalsIgnoreCase("Negotiation"))
			{
				spanco[3]++;
				value[3]+=Float.parseFloat(customer.getnProjUsdMillion());
			}
			if(customer.getvProspectingStage().equalsIgnoreCase("Close"))
			{
				spanco[4]++;
				value[4]+=Float.parseFloat(customer.getnProjUsdMillion());
			}
			if(customer.getvProspectingStage().equalsIgnoreCase("Order"))
			{
				spanco[5]++;
				value[5]+=Float.parseFloat(customer.getnProjUsdMillion());
			}
		}
		logger.info("count of SPANCO:");
		for (Integer s : spanco) {
			logger.info(s);
		}
		
		logger.info("value of SPANCO:");
		for (Float v : value) {
			logger.info(v);
		}
		
		countAndValue.add(spanco);
		countAndValue.add(value);
		logger.info("returning count and value");
		return countAndValue;
	}
	
	
	public List<Object[]> getFunnelOppCountAndValue(String pnl, List<Customer> customers) {
		logger.info("entered in getFunnelOppCountAndValue(pnl,customers) method of "+getClass());
		Integer[] spanco=new Integer[6];
		for(int i=0;i<6;i++)
			spanco[i]=0;
		Float[] value=new Float[6];
		for(int i=0;i<6;i++)
			value[i]=0.0f;
	  List<Object[]> countAndValue=new ArrayList<Object[]>(); 
	  for(Customer customer:customers)
		{
		  if(customer.getPnlAc().equalsIgnoreCase(pnl))
		  {
		if(customer.getvProspectingStage().equalsIgnoreCase("Suspect"))
		{
			spanco[0]++;
			value[0]+=Float.parseFloat(customer.getnProjUsdMillion());
		}
		if(customer.getvProspectingStage().equalsIgnoreCase("Prospect"))
		{
			spanco[1]++;
	    	value[1]+=Float.parseFloat(customer.getnProjUsdMillion());
		}
		if(customer.getvProspectingStage().equalsIgnoreCase("Approach"))
		{
			spanco[2]++;
			value[2]+=Float.parseFloat(customer.getnProjUsdMillion());
		}
		if(customer.getvProspectingStage().equalsIgnoreCase("Negotiation"))
		{
			spanco[3]++;
			value[3]+=Float.parseFloat(customer.getnProjUsdMillion());
		}
		if(customer.getvProspectingStage().equalsIgnoreCase("Close"))
		{
			spanco[4]++;
			value[4]+=Float.parseFloat(customer.getnProjUsdMillion());
		}
		if(customer.getvProspectingStage().equalsIgnoreCase("Order"))
		{
			spanco[5]++;
			value[5]+=Float.parseFloat(customer.getnProjUsdMillion());
		}
		  }  
		}
	  logger.info("count of SPANCO:");
		for (Integer s : spanco) {
			logger.info(s);
		}
		
		logger.info("value of SPANCO:");
		for (Float v : value) {
			logger.info(v);
		}
	     countAndValue.add(spanco);
		countAndValue.add(value);
		logger.info("retuning number of opportunity and value according to fy and pnl");
		return countAndValue;
	}
}
