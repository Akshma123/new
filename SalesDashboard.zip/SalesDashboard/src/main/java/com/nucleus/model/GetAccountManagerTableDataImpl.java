package com.nucleus.model;

import java.util.ArrayList;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.nucleus.controller.InitialController;
import com.nucleus.domain.Customer;

public class GetAccountManagerTableDataImpl implements GetAccountManagerTableData
{
	private Logger logger = Logger.getLogger(InitialController.class.getName());
	public List<Object[]> getAccountManagerCountAndValue(List<Customer> customers) {
		logger.info("entered in getAccountManagerCountAndValue(customers) method of "+getClass());
		List<Object[]> accountManagerCountAndValue=new ArrayList<Object[]>(); 
		Set<String> ams1=new LinkedHashSet<String>();
	for(Customer customer:customers)
	{
		ams1.add(customer.getMarketRep());
	}
	int length=ams1.size();
	  List<String> ams=new ArrayList<String>();
	  Integer[] count=new Integer[length];
	  Float[] value=new Float[length];
	String[] name=new String[length];
	  for(int i=0;i<length;i++)
	  {
		
		  count[i]=1;
		   value[i]=0.0f;
	  }
	for(Customer customer:customers)
	{
		if(ams.contains(customer.getMarketRep()))
		{
			int i=ams.indexOf(customer.getMarketRep());
			count[i]++;
			value[i]+=Float.parseFloat(customer.getnProjUsdMillion());
		}
		else
		{
			ams.add(customer.getMarketRep());
			int i=ams.indexOf(customer.getMarketRep());
			value[i]+=Float.parseFloat(customer.getnProjUsdMillion());
		}
	}

	for(int i=0;i<ams.size();i++)
	{
		name[i]=ams.get(i);
	}
	logger.info("name, count and values:");
	for(int i=0;i<name.length;i++)
	{
		logger.info(name[i]+"-------------"+count[i]+"----------------"+value[i]);
	}
	for(int i=0;i<name.length;i++)
	{
		name[i]=name[i].toUpperCase();
	}
	accountManagerCountAndValue.add(name);
	accountManagerCountAndValue.add(count);
	accountManagerCountAndValue.add(value);
	return accountManagerCountAndValue;
	}
	
	
	
	public List<Object[]> getAccountManagerCountAndValue(String pnl, List<Customer> customers) {
   logger.info("entered in getAccountManagerCountAndValue(pnl,customers) method of "+getClass());
		 List<Object[]> accountManagerCountAndValue=new ArrayList<Object[]>(); 
			Set<String> ams1=new LinkedHashSet<String>();
		for(Customer customer:customers)
		{
			if(customer.getPnlAc().equalsIgnoreCase(pnl))
			ams1.add(customer.getMarketRep());
		}
		  int length=ams1.size();
		  List<String> ams=new ArrayList<String>();
		  Integer[] count=new Integer[length];
		  Float[] value=new Float[length];
		 String[] name=new String[length];
		  for(int i=0;i<length;i++)
		  {
			  count[i]=1;
			   value[i]=0.0f;
		  }
		 
		for(Customer customer:customers)
		{
			 if(customer.getPnlAc().equalsIgnoreCase(pnl))
				{
			if(ams.contains(customer.getMarketRep()))
			{
				int i=ams.indexOf(customer.getMarketRep());
				count[i]++;
				value[i]+=Float.parseFloat(customer.getnProjUsdMillion());
			
			}
			else
			{
				ams.add(customer.getMarketRep());
				int i=ams.indexOf(customer.getMarketRep());
				value[i]+=Float.parseFloat(customer.getnProjUsdMillion());
			}
		}
		}	
		for(int i=0;i<ams.size();i++)
		{
			name[i]=ams.get(i);
		}
		logger.info("name, count and values:");
		for(int i=0;i<name.length;i++)
		{
			logger.info(name[i]+"-------------"+count[i]+"----------------"+value[i]);
		}
		for(int i=0;i<name.length;i++)
		{
			name[i]=name[i].toUpperCase();
		}
		accountManagerCountAndValue.add(name);
		accountManagerCountAndValue.add(count);
		accountManagerCountAndValue.add(value);
      logger.info("returning account manager names,count and value");
		return accountManagerCountAndValue;
	}
	
	
	
}
