package com.nucleus.model;

import java.util.List;

import com.nucleus.domain.Customer;

public interface GetQuarterTableData 
{
	public List<Object[]> getQuarterCountAndValue(String fy, List<Customer> customers);
	public List<Object[]> getQuarterCountAndValue(String fy, String pnl, List<Customer> customers);
}
